﻿namespace Application.Order.Interfaces
{
    public abstract class IDiscount
    {
        public abstract float GetDiscountPercentage();
    }
}
