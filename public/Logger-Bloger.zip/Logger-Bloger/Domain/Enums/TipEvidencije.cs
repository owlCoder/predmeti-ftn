namespace Domain.Enums;

public enum TipEvidencije
{
    INFO = 1,
    ERROR = 2,
    WARNING = 3
}
