namespace Domain.Enums;

public enum TipObjave
{
    VLOG = 1,
    FRIENDS = 2,
    FAMILY = 3
}
