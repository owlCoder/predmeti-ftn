namespace Presentation.Composition;

/// <summary>Uloga korisnika koja određuje koju vrstu zapisa kreira i pregleda.</summary>
public enum TipKorisnika
{
    Loger,
    Bloger
}
