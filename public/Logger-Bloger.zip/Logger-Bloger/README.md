# Logger-Bloger — .NET 8 Console (Clean Architecture)

Konzolna aplikacija organizovana po principima Clean Architecture i SOLID, sa
`Console App` prezentacionim slojem i `Result` pattern pristupom. Korisnik bira
ulogu **Loger** (evidencije/logovi) ili **Bloger** (objave) i kreira/pregleda
odgovarajuće zapise. Podrazumevani in-memory režim omogućava trenutno pokretanje.

Struktura je usklađena sa `ERS-Project-Template`.

## Struktura (solution sa pet projekata)

Otvori `Loger-Bloger.sln`. Solution sadrži:

- `Domain` — class library: modeli (`Korisnik`, `Objava`, `Evidencija`,
  `ZapisNaSajtu`), enumi, ugovori (`Contracts`), interfejsi (repozitorijumi,
  servisi, `IPasswordHasher`, baza) i `Result`. **Ne zavisi ni od jednog drugog
  projekta.**
- `Infrastructure` — class library: implementacije servisa
  (`AutentifikacioniServis`, `BlogServis`, `EvidencijaServis`,
  `FileLoggerServis`) i bezbednosti (`Sha256PasswordHasher`). Zavisi samo od
  domena.
- `Database` — class library: provajderi skladišta (`in-memory`, `json`),
  `DatabaseProviderFactory` i repozitorijumi. Zavisi samo od domena.
- `Presentation` — Console App (Exe): meni iza `IConsoleIO` apstrakcije, seeder,
  composition root (`AppContainer`) i `Program.cs`. Pokreće se ovaj projekat.
- `Tests` — NUnit + Moq testovi za domen i servise.

Pravac zavisnosti ide ka domenu; domen ne zna za prezentaciju ni za bazu.

## SOLID akcenti

- **DIP** — `AutentifikacioniServis` zavisi od `IPasswordHasher`, a meni od
  `IConsoleIO`; konkretne implementacije se uvezuju samo u composition root-u.
- **ISP/SRP** — auth servis radi samo `Registracija`/`Prijava`; podizanje
  podrazumevanih korisnika je izdvojeno u `KorisniciSeeder`.
- **OCP** — algoritam heširanja menja se zamenom `IPasswordHasher`
  implementacije; izbor skladišta menja se kroz `DatabaseProviderFactory`.

## Šta je promenjeno u odnosu na raniju verziju

- `Services` projekat → `Infrastructure` (po template-u).
- `Application` projekat ukinut; entry point je sada `Presentation`.
- Tuple/`bool` povratne vrednosti → `Result` / `Result<T>`.
- Lozinke se više ne čuvaju u čistom obliku — drži se SHA-256 heš.
- Izbor baze podataka više nije nasumičan; bira se kroz factory (`in-memory`
  podrazumevano, `json` opciono u `Program.cs`).
- Suvišan `IVebStranicaServis` (čist prolaz ka auth+zapisi) je uklonjen; meni
  koristi servise direktno.
- Centralizovan build kroz `Directory.Build.props`.

## Baza

Podrazumevano radi sa in-memory skladištem. U `Program.cs` se kroz
`AppContainer.Create("in-memory")` može preći na `"json"` (perzistencija u
`podaci.json`).

## Pokretanje

```bash
dotnet build Loger-Bloger.sln
dotnet run --project Presentation
dotnet test Loger-Bloger.sln
```

Podrazumevani korisnici (seed): `maja` / `123` i `ana` / `123`.
